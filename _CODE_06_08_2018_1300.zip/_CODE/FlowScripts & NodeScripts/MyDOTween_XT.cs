﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using FlowCanvas.Nodes;
using ParadoxNotion.Design;
using NodeCanvas.Framework;
using Sirenix.Serialization;
[Category("_MyNodes/DOTween")]
[Name("SetEase_Ease")]
public class SetEase :  CallableFunctionNode<Tweener, Tweener, Ease>{
    public override Tweener Invoke(Tweener a, Ease b)
    {
        a.SetEase(b);
        return a;
    }
}

[Category("_MyNodes/DOTween")]
[Name("SetEase_Curve")]
public class SetEasefromCurve : CallableFunctionNode<Tweener, Tweener, AnimationCurve>
{
    public override Tweener Invoke(Tweener tweener, AnimationCurve curve)
    {
        tweener.SetEase(curve);
        return tweener;
    }
}


[Category("_MyNodes/DOTween")]
[Name("_DOTween_Generic_Curve")]
public class _DoTween_G_Curve : CallableFunctionNode<float,float,float,float, AnimationCurve>
{	
	
	private float outValue { get; set; }
	public override float Invoke(float startValue,float endValue, float duration, AnimationCurve curve)
	{
		DOTween.To(
			() => startValue,
			(x) => outValue = x,
			endValue,
			duration).
			SetEase(curve);
		return outValue;
	}
	
}

[Category("_MyNodes/DOTween")]
[Name("_DOTween_Generic_Ease")]
public class _DoTween_G_Ease : CallableFunctionNode<float,float,float,float, Ease>
{
	public float outValue;
	public override float Invoke(float startValue,float endValue, float duration, Ease ease)
	{
		DOTween.To(
			() => startValue,
			(x) => outValue = x,
			endValue,
			duration).
			SetEase(ease);
		return outValue;
	}
}


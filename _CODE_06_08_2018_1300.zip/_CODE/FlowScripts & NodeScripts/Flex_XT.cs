﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Flex;
using ParadoxNotion.Design;
namespace FlowCanvas.Nodes
{	
	[Name("My Game Event")]
    public class MyGameEvent : EventNode
    {
        public GameEvent theEvent;

        private FlowOutput raised;

        public    override void OnGraphStarted() { theEvent.OnEventRaised  += EventRaised; }
        public    override void OnGraphStoped()  { theEvent.OnEventRaised  -= EventRaised; }
        protected override void RegisterPorts()  { raised = AddFlowOutput("Out"); }

	    public void EventRaised(Object theRaiser){ raised.Call(new Flow()); }

    }

}
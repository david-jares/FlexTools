﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using FlowCanvas.Nodes;
using ParadoxNotion.Design;
using NodeCanvas.Framework;

namespace FlowCanvas.Nodes{
 
    [Category("_MyNodes/DOTween")]
    [Name("~DOT_Float_Ease")]
    [Description("Tween a FloatVar and Fire Output-Flow-Events During Animation")]
    public class DOT_Float_Ease : FlowControlNode
    {

        public bool useCurve = false; // TODO Schau mal in den FOren nach infos für dynamisches GUI
        
        private Tweener theTweener;
        private float   outValue;
        protected override void OnNodeInspectorGUI()
        {

            if (GUILayout.Button("Refresh Ports"))
            {
                GatherPorts();
            }
            base.OnNodeInspectorGUI();
        }

        protected override void OnNodeGUI()
        {
            base.OnNodeGUI();
        }

        protected override void RegisterPorts(){
            
            
            var startValue       = AddValueInput<float>   ("startValue");
            var endValue         = AddValueInput<float>   ("end Value");
            var duration         = AddValueInput<float>   ("duration");

            ValueInput<AnimationCurve> theCurve = null;
            ValueInput<Ease> theEase = null;
            if (useCurve)
            {    
                 theCurve             = AddValueInput<AnimationCurve>    ("curve");
            }
            else
            {
                theEase             = AddValueInput<Ease>    ("ease");
            }
            var loops            = AddValueInput<int>     ("loops");
            var loopType         = AddValueInput<LoopType>("LoopType");
            var outThing         = AddValueOutput<float>  ("outValue",()=> outValue );
            var tweenOnStart     = AddFlowOutput("Start"   );
            var tweenOnUpdate    = AddFlowOutput("Update"  );
            var tweenOnComplete  = AddFlowOutput("Complete");
            
            AddFlowInput("In", (f)=>
            {
                theTweener = DOTween.To(() => startValue.value, (x) => outValue = x, endValue.value ,duration.value);
                if (useCurve){ theTweener.SetEase ( theCurve.value);}
                else         { theTweener.SetEase ( theEase.value) ;}
                
                theTweener.SetLoops(loops.value, loopType.value);
                    
                theTweener.OnStart   (() => tweenOnStart   .Call(f));
                theTweener.OnUpdate  (() => tweenOnUpdate  .Call(f));
                theTweener.OnComplete(() => tweenOnComplete.Call(f));
            });
        }
    }
}

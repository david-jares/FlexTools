using ParadoxNotion.Design;
using Flex;
using System.Collections.Generic;
using UnityEngine;
namespace FlowCanvas.Nodes
{
    [Name("Debug-MyEventRaiserNode")]
    [Category("MyDebug/EventNode")]
    [Description("Will raise GameEvents")]
    public class EventRaiserNode : FlowControlNode
    {   
        public FlowOutput output;
        public Object raiserObject;
        protected override void RegisterPorts()
        {
           output = AddFlowOutput("OUT","OUT");
            //IN = AddFlowInput("IN",(f) => { } );
        }
    }
}

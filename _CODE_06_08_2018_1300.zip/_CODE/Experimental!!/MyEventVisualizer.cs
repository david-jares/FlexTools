using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NodeCanvas.Framework;
using FlowCanvas.Nodes;
using FlowCanvas;
using Sirenix.OdinInspector;
using Flex;
using System.Reflection;
using System.Linq;



public class MyEventVisualizer : MonoBehaviour {

    public class BonBon {
        public static HashSet<BonBon> allBonBons = new HashSet<BonBon>();
        public static HashSet<EventRaiserNode> ALLBonbonsRaiserNodes = new HashSet<EventRaiserNode>();
        public BonBon(){
            
            allBonBons.Add(this);
        }
        public EventHolderNode root;
        public readonly HashSet<EventRaiserNode>   raiserNodes     = new HashSet<EventRaiserNode>();
        public readonly HashSet<EventListenerNode> listenerNodes = new HashSet<EventListenerNode>();
    }

    public static Dictionary<Object, HashSet<FlexVariable>> allFlexRefHolders = new Dictionary<Object,HashSet<FlexVariable> >();
    public static Dictionary<FlexVariable, HashSet<Object>> allFlexVars2FlexRefHolders = new Dictionary<FlexVariable,HashSet<Object> >();

    public  GraphOwner eventGraphOwner;
    private Graph      eventGraph;
    private readonly List<Connection> allConnections = new List<Connection>();

    void Start (){
        eventGraph = eventGraphOwner.graph;
        //eventGraph.ClearGraph();
        CreateAllEventNodes();
        foreach(BonBon bonbon in  BonBon.allBonBons){
            // bonbon.root.theEvent.value.RegisterListener(delegate(Object theRaiser){});
            bonbon.root.theEvent.value.RegisterListener( (Object theRaiser)=>{
                OnEventWasCalled(bonbon.root.theEvent.value, theRaiser);
            },this);
        }

    }
    // private void OnDisable() {
    //     foreach(BonBon bonbon in  BonBon.allBonBons){
    //         bonbon.root.theEvent.value.UnRegisterListener(OnEventWasCalled);
    //     }
    // }
    public void testCall(Object o){

    }   
        HashSet<FlowOutput> flowOutputsWaitingForCall = new HashSet<FlowOutput>();
        public void OnEventWasCalled(FlexVariable theGameEvent,Object theRaiser){
            theGameEvent = theGameEvent as GameEvent;
            foreach(BonBon bonbon in BonBon.allBonBons){
                if(bonbon.root.theEvent.value == theGameEvent){
                    if(theRaiser != null){
                        EventRaiserNode raiserNode =  bonbon.raiserNodes.First(rn => rn.raiserObject == theRaiser);
                        Debug.Log("Raiser Node Found :) " + raiserNode.name);
                        if(raiserNode != null){
                            flowOutputsWaitingForCall.Add(raiserNode.output); 
                        }
                    }
                    foreach(FlowOutput f in bonbon.root.getFlowOutputs()){
                        flowOutputsWaitingForCall.Add(f);
                    }
                }
            }
    }
    void Update () {
        // for debugging purposes 
        // flowOutputsWaitingForCall need to be called from UpdateMethod, otherwise wont visualize as yellow in Graph 
        foreach(FlowOutput f in flowOutputsWaitingForCall){
            f.Call(new Flow());
        }
        flowOutputsWaitingForCall.Clear();

        // if (Input.GetKeyDown(KeyCode.Y)){
        //    //allConnections.Add( FlowCanvas.BinderConnection.Create(theNode1.out1, theNode2.In));
        //    BonBon.allBonBons.ToArray()[0].raiserNodes.ToArray()[0].output.Call(new Flow());
        // }
        // if (Input.GetKeyDown(KeyCode.A)){
        //    //allConnections.Add( FlowCanvas.BinderConnection.Create(theNode1.out1, theNode2.In));
        //    Debug.Log("Calling Manually : " +BonBon.allBonBons.ToArray()[0].root.getFlowOutputs()[0].name );
        //    BonBon.allBonBons.ToArray()[0].root.getFlowOutputs()[0].Call(new Flow());
        // }
        //  if (Input.GetKeyDown(KeyCode.Q)){
        //    //allConnections.Add( FlowCanvas.BinderConnection.Create(theNode1.out1, theNode2.In));
        //    Debug.Log("Calling Manually Event : " +BonBon.allBonBons.ToArray()[0].root.getFlowOutputs()[0].name );
        // }
	}

    [Button("CreateEventNodes")]
    private void CreateAllEventNodes()
    {   
        Debug.Log("Create all Event Nodes");

        updateSetOfFlexTypes();

        if (eventGraph == null) { eventGraph = eventGraphOwner.graph; }

        // create the EventNodes in the Middle
        Vector2 nextNodePos = new Vector2(2600,2600);
        
        // we have a static list of all instancses of Flexvariables that we can iterate over. it is automatically handled by Flexvariables
        foreach(FlexVariable flexVarInstance in FlexVariable.allFlexVariableInstances)
        {   
            // if there no Object has to do anything withthis one , then skip this one & continue with the next FlexVarInstance
            if(!allFlexVars2FlexRefHolders.ContainsKey(flexVarInstance))continue;

            Debug.Log("Found Flexvar : " + flexVarInstance.name);
            //currently restrict it to only gameevents
            if (flexVarInstance is GameEvent )
            {   
                
                Debug.Log("Creating Bonbon for  : " + flexVarInstance.name);
                BonBon bonbon      = new BonBon();
                bonbon.root          = eventGraph.AddNode<EventHolderNode>();
                bonbon.root.theEvent = flexVarInstance as GameEvent;
                bonbon.root.name     = flexVarInstance.name;

                //(fill the newly defined sets, connect, position. ) have fun then
                // Add the listeners to the right
                int yOffset = 0;

                // for each as Listener registered Component or ScriptableObject
                int loopcount =0;
                foreach(Object listener in bonbon.root.theEvent.value.allRegisteredEventListenerObjects)
                {   
                    Debug.Log("Going into the Loop 1 for the "+ ++loopcount+" st time  for :  " + listener);
                    // Create a Node into the Eventgraph
                    EventListenerNode listenerNode = eventGraph.AddNode<EventListenerNode>();
                    bonbon.listenerNodes.Add(listenerNode);
                    listenerNode.name              = listener.name;
                    listenerNode.listenerObject    = listener;
                    listenerNode.position          = nextNodePos + new Vector2(300, yOffset);
                    yOffset += 100;


                    // create a connection in the graph for it
                    if(!bonbon.root.flowOutputTargets.ContainsKey(listener)){
                        bonbon.root.flowOutputTargets.Add(listener , listener.GetHashCode().ToString());
                    }
                    eventGraph.Validate(); // MUST be CALLED BEFORE ADDING CONNECTION
                    allConnections.Add(BinderConnection.Create(bonbon.root.GetOutputPort(listener.GetHashCode().ToString()), listenerNode.IN));
                }

                // Add all reference-Objects ( inclusive raisers ) on the left
                int yOffset2 = 0;
                if(allFlexVars2FlexRefHolders.ContainsKey(flexVarInstance)){
                    foreach (Object flexRefHolda  in allFlexVars2FlexRefHolders[flexVarInstance].OrderBy(s=>s.name) )
                    {   
                        // first create a graphnode for the flexrefholderObject
                        EventRaiserNode raiserNode = eventGraph.AddNode<EventRaiserNode>();
                        bonbon.raiserNodes.Add(raiserNode);
                        raiserNode.name            = flexRefHolda.name;
                        raiserNode.raiserObject    = flexRefHolda;
                        raiserNode.position        = nextNodePos + new Vector2(-300, yOffset2);
                        yOffset2 += 100;


                        if(!bonbon.root.flowInputSources.ContainsKey(flexRefHolda)){
                            bonbon.root.flowInputSources.Add(flexRefHolda , flexRefHolda.GetHashCode().ToString());
                        }
                        eventGraph.Validate(); // MUST be CALLED BEFORE ADDING CONNECTION
                        allConnections.Add(BinderConnection.Create(raiserNode.GetOutputPort("OUT"),bonbon.root.GetInputPort(flexRefHolda.GetHashCode().ToString()) ));

                    }
                }
                bonbon.root.position   = nextNodePos;
                nextNodePos            = new Vector2(nextNodePos.x, nextNodePos.y + 250 +Mathf.Max(yOffset,yOffset2));
            }
        }
                eventGraph.Validate();// WICHTIG zum Uodaten der In/Outputs von den Nodes;
    }


    [Button("updateSetOfFlexTypes")]
    public void updateSetOfFlexTypes()
    {
        //allFlexReferences.Clear();
        SearchAndExtract( Resources.FindObjectsOfTypeAll<MonoBehaviour>());
        SearchAndExtract( Resources.FindObjectsOfTypeAll<ScriptableObject>());
        // TODO GrAPHS ARE MISSING `?? Graphs, using events/ refs...
    }

    /// find all FlexreferenceHolders on all Objects of a Type and save these objects together with their variables they reference
	private static void SearchAndExtract<T>(T[] myArray) where T:Object
    {   
        // for each object in the given array/list of Objects
        foreach (T someObject in myArray)
        {   
            // find all Fields on each all components of the object
            FieldInfo[] myfields = someObject.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance);
            //for each found field
            foreach (FieldInfo field in myfields)
            {   
                //check if the field is of Type Flexreference
                FlexReference flexReference = field.GetValue(someObject) as FlexReference;
                
                if(flexReference == null)continue;
                if(flexReference.GetVariable() == null)continue;

                FlexVariable theVariable = flexReference.GetVariable() as FlexVariable;
                // if we havenot yet  saved this object as a key in our Dictionary, add one
                if (!allFlexRefHolders.ContainsKey(someObject))
                {
                    allFlexRefHolders.Add(someObject, new HashSet<FlexVariable>());
                }
                // add this flexreference to the dictionary key-object into the set of values
                allFlexRefHolders[someObject].Add(theVariable); 

                // Das Ganze jetzt Umgekehrt
                if(!allFlexVars2FlexRefHolders.ContainsKey(theVariable)){
                    allFlexVars2FlexRefHolders.Add(theVariable, new HashSet<Object>());
                }
                
                allFlexVars2FlexRefHolders[theVariable].Add(someObject);

                // Debug.Log(" on : "        + someObject.name + 
                //         "   Found : "     + field.Name + 
                //         " ; added type :" + someObject.GetType());
            
            }
        }
        
    }
}

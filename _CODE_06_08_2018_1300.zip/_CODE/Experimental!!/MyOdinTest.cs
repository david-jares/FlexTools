﻿
using UnityEngine;
using UnityEngine.Events;
using Flex;
using Sirenix.Serialization;
using Sirenix.OdinInspector;
namespace Flex
{
		public class MyOdinTest : SerializedMonoBehaviour {
		[OdinSerialize]
		public float autoProp{get; set;}
		
		private float nonAutoProp;
		
			[OdinSerialize]
		public float NonAutoProp{
		get{
			return nonAutoProp;
		}
		set{
			nonAutoProp = value;
			Debug.Log("NonAutoProp Set");
		}
		}
		[Button]
		public void doSomeDebug(){
			Debug.Log("didSome Debug :)");
		}
		public void doSomeOtherDebug(string s){
			Debug.Log(s);
		}
	

}
}

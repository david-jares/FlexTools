using ParadoxNotion.Design;
using Flex;
using System.Collections.Generic;
using UnityEngine;
namespace FlowCanvas.Nodes
{
    [Name("Debug-MyEventListenerNode")]
    [Category("MyDebug/EventNode")]
    [Description("Will hold GameEvents")]
    public class EventListenerNode : FlowControlNode
    {   
        public Object listenerObject;
        public FlowInput IN;
        protected override void RegisterPorts()
        {
            IN = AddFlowInput("IN",(f) => { } );
        }
    }
}

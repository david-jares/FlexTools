using ParadoxNotion.Design;
using Flex;
using System.Collections.Generic;
using UnityEngine;
namespace FlowCanvas.Nodes
{

    [Name("Debug-MyEventHolderNode")]
    [Category("MyDebug/EventNode")]
    [Description("Will hold GameEvents")]
    public class EventHolderNode : FlowControlNode
    {

        public NodeCanvas.Framework.BBParameter<GameEvent> theEvent;
        public FlowInput  IN; 
        //public FlowOutput out1; 
        //public List<FlowOutput> outputs = new List<FlowOutput>();


    // The targetObjects and its ids as string
        public Dictionary<Object,string>    flowOutputTargets = new Dictionary<Object,string>();
        List<FlowOutput> flowOutputs = new List<FlowOutput>();
        public List<FlowOutput> getFlowOutputs(){
                return flowOutputs;
        }
        public Dictionary<Object,string>    flowInputSources = new Dictionary<Object,string>();
        List<FlowInput> flowInputs = new List<FlowInput>();
        //

        int timesRegistered = 0;

        protected override void RegisterPorts()
        {
            // if (theEvent.value !=
            foreach(Object o in flowOutputTargets.Keys ){
                flowOutputs.Add( AddFlowOutput(o.name,flowOutputTargets[o]));
            }
            foreach(Object o in flowInputSources.Keys ){
                flowInputs.Add( AddFlowInput(o.name,flowInputSources[o],(f)=>{
                    foreach(FlowOutput flowOutput in flowOutputs){
                    
                     flowOutput.Call(f);}
                }));
            }

            Debug.Log( "EventHolderNode :"+ this.name + "  -  "  + ++timesRegistered + " x called RegisterPorts() : OUtputs " + flowOutputs.Count);
        }

    }
}
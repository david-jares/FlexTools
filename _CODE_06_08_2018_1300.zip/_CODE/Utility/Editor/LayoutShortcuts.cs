﻿using UnityEngine;
 using UnityEditor;
 
 public class LayoutShortcuts : EditorWindow {
 
	 [MenuItem("Window/LayoutShortcuts/Dave_DEFAULT &1", false, 999)]
	 static void Layout1() {
		 EditorApplication.ExecuteMenuItem("Window/Layouts/Dave_DEFAULT");
	 }
 
	 [MenuItem("Window/LayoutShortcuts/Dave_WID &2", false, 999)]
	 static void Layout2() {
		 EditorApplication.ExecuteMenuItem("Window/Layouts/Dave_WIDE");
	 }
	 [MenuItem("Window/LayoutShortcuts/Dave_WIDER &3", false, 999)]
	 static void Layout3() {
		 EditorApplication.ExecuteMenuItem("Window/Layouts/Dave_WIDER");
	 }
	 [MenuItem("Window/LayoutShortcuts/Dave_WIDEST &4", false, 999)]
	 static void Layout4() {
		 EditorApplication.ExecuteMenuItem("Window/Layouts/Dave_WIDEST");
	 }
 
 }
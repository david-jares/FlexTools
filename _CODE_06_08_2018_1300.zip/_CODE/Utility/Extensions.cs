﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Extensions  {
    
    // Transforms
    public static void set_X_Pos_world(this Transform t, float x) { t.position = new Vector3(x                , t.position.y, t.position.z);}
    public static void set_Y_Pos_world(this Transform t, float y) { t.position = new Vector3(t.position.x ,                y, t.position.z);}
    public static void set_Z_Pos_world(this Transform t, float z) { t.position = new Vector3(t.position.x ,     t.position.y,            z);}


    //AnimationCurves
    public static void copyValuesFrom(this AnimationCurve targetCurve, AnimationCurve otherCurve)
    {
        targetCurve.keys         = otherCurve.keys;
        targetCurve.preWrapMode  = otherCurve.preWrapMode;
        targetCurve.postWrapMode = otherCurve.postWrapMode;
    }
    // Shuffling Arrays
    private static System.Random rng = new System.Random();
    public static void Shuffle<T>(this T[] array)
    {
        rng = new System.Random();
        int n = array.Length;
        while (n > 1)
        {
            int k = rng.Next(n);
            n--;
            T temp = array[n];
            array[n] = array[k];
            array[k] = temp;
        }
    }
}

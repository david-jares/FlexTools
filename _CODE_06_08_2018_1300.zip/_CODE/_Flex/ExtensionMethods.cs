﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public static class ExtensionMethods  {
   
    public static T findScriptableObject<T>(string objectName )
    {
        object[] objects = Resources.FindObjectsOfTypeAll(typeof(T));
        foreach (object o in objects)
        {
            ScriptableObject so = (ScriptableObject)o;
            if (so != null && so.name == objectName)
            {
                return (T)o;
            }
        }
        Debug.LogError(" Could Not Find GameEvent-Asset with name : " + objectName);
        //return null;
        return default(T);
    }

}

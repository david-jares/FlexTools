﻿using UnityEditor;
using UnityEngine;



namespace Flex
{
    [CustomEditor(typeof(VariableGenerator))]
    public class VariableGeneratorEditor : Editor
    {   
        [ExecuteInEditMode]
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
            GUI.enabled = !Application.isPlaying;

            VariableGenerator vg = target as VariableGenerator;
            if (GUILayout.Button("GENERATE"))  vg.Generate();
        }
    }
}
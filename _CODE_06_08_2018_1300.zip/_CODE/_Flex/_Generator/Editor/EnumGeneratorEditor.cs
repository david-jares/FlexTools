﻿using UnityEditor;
using UnityEngine;



namespace Flex
{
    [CustomEditor(typeof(EnumGenerator))]
    public class EnumGeneratorEditor : Editor
    {   
        [ExecuteInEditMode]
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
            GUI.enabled = !Application.isPlaying;

            EnumGenerator eg = target as EnumGenerator;
            if (GUILayout.Button("GENERATE"))  eg.Generate();
        }
    }
}
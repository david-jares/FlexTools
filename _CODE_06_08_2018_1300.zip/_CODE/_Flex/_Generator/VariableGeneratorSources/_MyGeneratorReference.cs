﻿/*
using System;
using UnityEngine;

namespace Flex
{
    [Serializable]
    public class _MyGeneratorReference
    {
        public bool UseConstant = true;
        public _MyGenerator ConstantValue;
        public _MyGeneratorVariable Variable;

        public _MyGeneratorReference()
        { }

        public _MyGeneratorReference(_MyGenerator value)
        {
            UseConstant = true;
            ConstantValue = value;
        }

        public _MyGenerator Value
        {
            get { return UseConstant ? ConstantValue : Variable.GetValue(); }
        }

        public bool IsSafe()
        {
            return ( UseConstant || Variable != null);
        }
        //public static implicit operator _MyGenerator(_MyGeneratorReference reference)
        //{
        //    return reference.Value;
        //}
    }
}
*/
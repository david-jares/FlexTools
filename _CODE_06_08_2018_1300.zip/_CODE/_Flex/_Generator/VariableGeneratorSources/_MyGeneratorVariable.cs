﻿/*
using UnityEngine;
using Flex;
namespace Flex
{
    [CreateAssetMenu(menuName = "Variables/_MyGeneratorVariable", order = 0)]
    public class _MyGeneratorVariable : GameEvent
    {
#if UNITY_EDITOR
        [Multiline]
        public string DeveloperDescription = "";
#endif

        [SerializeField]
        private bool readOnly = false;
        [SerializeField]
        private bool usePersistentStartValue = false;

        [SerializeField]
        private _MyGenerator persistentStartValue;
        [Space(30)]
        [SerializeField]
        private _MyGenerator _Value;

        private void OnEnable()
        {
            if (usePersistentStartValue)
                _Value = persistentStartValue;
        }


        public _MyGenerator GetValue()
        {
            return _Value;
        }


        public void SetValue(_MyGenerator value)
        {
            if (readOnly == false)
            {
                _Value = value;
                Raise();
            }
            else
            {
                Debug.LogError(this.name + " : Attempting to assign a Value of Readonly-Variable");
            }
        }

        public void SetValue(_MyGeneratorVariable value)
        {
            if (readOnly == false)
            {
                _Value = value.GetValue();
                Raise();
            }
            else
            {
                Debug.LogError(this.name + " : Attempting to assign a Value of Readonly-Variable");
            }
        }


        public void SetValuePersistently(_MyGenerator value)
        {
            if (readOnly == false)
            {
                _Value = value;
                persistentStartValue = value;
                Raise();
            }
            else
            {
                Debug.LogError(this.name + " : Attempting to assign a Value of Readonly-Variable");
            }
        }

        public void SetValuePersistently(_MyGeneratorVariable value)
        {
            if (readOnly == false)
            {
                _Value = value.GetValue();
                persistentStartValue = value.GetValue();
                Raise();
            }
            else
            {
                Debug.LogError(this.name + " : Attempting to assign a Value of Readonly-Variable");
            }
        }


    }
}
*/
﻿/*
using UnityEditor;
using UnityEngine;
using Flex;

namespace Flex
{

    [CustomEditor(typeof(_MyGeneratorVariable))]
    public class _MyGeneratorVariableEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            _MyGeneratorVariable e = target as _MyGeneratorVariable;
            if (GUILayout.Button("Raise : on_MyGeneratorVariableChangeEvent()"))
                e.Raise();
        }
    }
}
*/
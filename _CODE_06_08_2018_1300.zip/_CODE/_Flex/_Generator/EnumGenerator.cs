﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using Flex;

[ExecuteInEditMode]
public class EnumGenerator : MonoBehaviour {

    public string nameOfNewType = "";
    [Tooltip("Willl be overwritten by the newTypeName")]
    [Space(20)]
    public string genericTypeName = "_MyGeneratorE";
    public string destinationFolderPath = "Assets/_GAME/_Scripts/_Flex/Enums/Generated_Enums/";

    [Header("Source-File-Paths")]
    public string sourceVariableFile        = "Assets/_GAME/_Scripts/_Flex/_Generator/EnumGeneratorSources/_MyGeneratorEVariable.cs";

    public string sourceVariableEditorFile  = "Assets/_GAME/_Scripts/_Flex/_Generator/EnumGeneratorSources/_MyGeneratorEVariableEditor.cs";

    public string sourceReferenceFile       = "Assets/_GAME/_Scripts/_Flex/_Generator/_Generator/EnumGeneratorSources/_MyGeneratorEReference.cs";

    public string sourceReferenceDrawerFile = "Assets/_GAME/_Scripts/_Flex/_Generator/_Generator/EnumGeneratorSources/_MyGeneratorEReferenceDrawer.cs";

    public string sourceEnumFile            = "Assets/_GAME/_Scripts/_Flex/_Generator/_Generator/EnumGeneratorSources/Enum_MyGeneratorE.cs";

    private bool CreateVariableFile(string sourceFilePath, string dstFolderPath  , string dstPostfix = "")
    {   

        string fileContent = File.ReadAllText(sourceFilePath);
        fileContent =  fileContent.Replace(genericTypeName, nameOfNewType);
        fileContent = fileContent.Replace("/*", "");
        
        fileContent = fileContent.Replace("*/", "");
        Debug.Log("\n\nNew file Content : \n" + fileContent);

        dstPostfix = dstPostfix.EndsWith("/") ? dstPostfix : dstPostfix + ("/");
        string[] splittedStrings = sourceFilePath.Split(new string[] { genericTypeName }, StringSplitOptions.None);
        string suffix = splittedStrings.Length >1 ? splittedStrings[1] : "";
        string fileNameVariable = dstFolderPath + dstPostfix + nameOfNewType + suffix;
        if (File.Exists(fileNameVariable))
        {
            Debug.Log(fileNameVariable + " already exists.");
            return false;
        }

        var newFile = File.CreateText(fileNameVariable);
        newFile.WriteLine(fileContent);
        newFile.Close();
        return true;
    }

    public void Generate () {

            if (nameOfNewType.Equals("")) {
                Debug.LogError("Name Of New VariableType has not been Set in the Inspecotor dude");
                return;
            }
            if (File.Exists(sourceVariableFile) && File.Exists( sourceVariableEditorFile) && File.Exists(sourceReferenceFile) && File.Exists(sourceReferenceDrawerFile) && File.Exists(sourceEnumFile))
            {
                CreateVariableFile(sourceVariableFile, destinationFolderPath);
                CreateVariableFile(sourceVariableEditorFile,destinationFolderPath, "Editor");

                CreateVariableFile(sourceReferenceFile, destinationFolderPath);
                CreateVariableFile(sourceReferenceDrawerFile,destinationFolderPath, "Editor");

                Directory.CreateDirectory("Assets/_GAME/_Scripts/_Code/Enums/" + nameOfNewType);
                CreateVariableFile(sourceEnumFile, "Assets/_GAME/_Scripts/_Code/Enums/"+nameOfNewType);
                
            }
            else
            {
                Debug.LogError("Couldnt generate Variables - Template Filepaths Incorrect ");
                Debug.Log(File.Exists(sourceVariableFile) +" "+ File.Exists(sourceVariableEditorFile) +" "+ File.Exists(sourceReferenceFile) + " " + File.Exists(sourceReferenceDrawerFile) + " " + File.Exists(sourceEnumFile));
                return;
            }

    }

    
}

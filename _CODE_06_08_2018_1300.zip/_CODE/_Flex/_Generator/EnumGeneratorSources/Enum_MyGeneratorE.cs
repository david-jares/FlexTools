﻿/*
using UnityEngine;

[CreateAssetMenu(menuName ="Enums/_MyGeneratorE")]
public class _MyGeneratorE : ScriptableObject {
	
}
*/
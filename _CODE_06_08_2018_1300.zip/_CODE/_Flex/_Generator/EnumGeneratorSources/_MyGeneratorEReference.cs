/*
using System;
using UnityEngine;

namespace Flex
{
    [Serializable]
    public class _MyGeneratorEReference : EnumBase
    {
        public bool UseConstant = true;
        public _MyGeneratorE ConstantValue;
        public _MyGeneratorEVariable Variable;

        public _MyGeneratorEReference()
        { }

        public _MyGeneratorEReference(_MyGeneratorE value)
        {
            UseConstant = true;
            ConstantValue = value;
        }

        public _MyGeneratorE Value
        {
            get { return UseConstant ? ConstantValue : Variable.GetValue(); }
        }

        public bool IsSafe()
        {
            return ( UseConstant || Variable != null);
        }
        public static implicit operator _MyGeneratorE(_MyGeneratorEReference reference)
        {
            return reference.Value;
        }
    }
}

*/
/*
using UnityEngine;
using Flex;
using System;

namespace Flex
{
    [CreateAssetMenu(menuName = "Enums/_Variables/_MyGeneratorEVariable", order = 0)]
    public class _MyGeneratorEVariable : GameEvent
    {
#if UNITY_EDITOR
        [Multiline]
        public string DeveloperDescription = "";
#endif
        public _MyGeneratorE value;

        public _MyGeneratorE GetValue()
        {
            return value;
        }
    }
}

*/
﻿/*
using UnityEditor;
using UnityEngine;
using Flex;

namespace Flex
{

    [CustomEditor(typeof(_MyGeneratorEVariable))]
    public class _MyGeneratorEVariableEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            _MyGeneratorEVariable e = target as _MyGeneratorEVariable;
            if (GUILayout.Button("Raise : on_MyGeneratorEVariableChangeEvent()"))
                e.Raise();
        }
    }
}
*/
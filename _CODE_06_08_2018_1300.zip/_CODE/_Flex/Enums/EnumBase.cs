﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
//[Serializable]
public class EnumBase 
{
    public static T GetAsEnum<T>(string enumItemName)
    {
        return (T)System.Enum.Parse(typeof(T), enumItemName, true);
    }
}
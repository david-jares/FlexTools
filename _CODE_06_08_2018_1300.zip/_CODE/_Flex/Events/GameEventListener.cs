
using UnityEngine;
using UnityEngine.Events;
using Sirenix.OdinInspector;
using Sirenix.Serialization;
namespace Flex
{
    public class GameEventListener : SerializedMonoBehaviour, IGameEventListener
    {
        [Tooltip("Event to register with.")]
        
        public IGameEvent Event;

        [Tooltip("Response to invoke when Event is raised.")]
        public UnityEvent Response;

        private void OnEnable()
        {
            if (Event != null)
            {
                Event.RegisterListener(this);
            }
            else
            {
                Debug.LogError("Missing Event to register to");
            }
        }

        private void OnDisable()
        {
            if (Event != null)
            {
                Event.UnregisterListener(this);
            }
            else
            {
                Debug.LogError("Missing Event to unRegister from");
            }
        }

        [Button("Invoke the Response :)",ButtonSizes.Large)]
        public virtual void OnEventRaised(Object theCaller)
        {
            Response.Invoke();
        }
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Flex
{

    public interface IGameEvent
    {

        void RegisterListener(IGameEventListener listener);

        void UnregisterListener(IGameEventListener listener);


    }
}
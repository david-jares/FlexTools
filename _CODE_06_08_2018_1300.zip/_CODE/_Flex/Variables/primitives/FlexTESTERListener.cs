﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Flex;
public class FlexTESTERListener : MonoBehaviour {

	// public FlexFloatReference flexFloatReference1;
	// public FlexFloatReference flexFloatReference2;
	public GameEventReference someGameEvent1;


	private void OnEnable() {
		someGameEvent1.Variable.RegisterListener(callMeBackPlease ,this);
	}
	private void OnDisable() {
		someGameEvent1.Variable.UnRegisterListener(callMeBackPlease,this);
	}

	public void callMeBackPlease(Object theRaiser){
		Debug.Log(this.name + " : I  have been raised Back from  : " );//+ theRaiser?.name);
	}
}

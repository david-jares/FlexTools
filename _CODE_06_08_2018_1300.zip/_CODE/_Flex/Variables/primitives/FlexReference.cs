using UnityEngine;
using UnityEngine.Events;
using Sirenix.Serialization;
using Sirenix.OdinInspector;
using System.Collections.Generic;
using System.Reflection;
namespace Flex
{   
    public class FlexReference
    {
        public static readonly HashSet<FlexReference> allFlexReferenceInstances = new HashSet<FlexReference>();
       public virtual Object GetVariable()
        {
            //gets the Variable, not the Variablevalue. 
            //Althought the field of the variabble is public, having a method is Useful for special-purpose.inheritance-stuff for special
            // But ! the returned type is of type Object!
            return null;
        }   
    }


	[System.Serializable]
	public class FlexReference<T, U > :FlexReference where U : FlexVariable<T>
    {
		// T is the FlexVariable
        

		public bool UseConstant = true;
		
		public T ConstantValue;
		
		public U Variable ;
        //[OdinSerialize,ShowInInspector]
        //public U Variable    {get;set;} 

        // subb classes should call base constructor
        public FlexReference() {
            //UnityEngine.GameObject.Fin
            allFlexReferenceInstances.Add(this);
            // Debug.Log("FlexRefConstructor called ,  amount allFlexRefInstances = " + allFlexReferenceInstances.Count + "  " + this.ToString());
        }
        public FlexReference(T value){
			UseConstant = true;
			ConstantValue = value;
            allFlexReferenceInstances.Add(this);
            // Debug.Log("FlexRefConstructor with VALUE called ,  amount allFlexRefInstances = " + allFlexReferenceInstances.Count +  "  " + this.ToString());
        }
        ~FlexReference(){
			allFlexReferenceInstances.Remove(this);
            // Debug.Log("FlexRef DESTructor called ,  amount allFlexRefInstances = " + allFlexReferenceInstances.Count);
            
        }

        public override Object GetVariable()
        {
            if(UseConstant) { return null; }
            return Variable;
        }
        public T Value
		{
			get { return UseConstant ? ConstantValue : Variable.Value; }
		}
		
		public static implicit operator T(FlexReference<T, U> reference)
		{
			return reference.Value;
		}
		[OnInspectorGUI]
		public void MyInspectorGUI(){
			GUILayout.Button("FUN");
		}
	}
}
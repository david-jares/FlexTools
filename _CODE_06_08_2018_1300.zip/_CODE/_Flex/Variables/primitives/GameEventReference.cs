﻿using UnityEngine;
using UnityEngine.Events;
using Sirenix.Serialization;
using Sirenix.OdinInspector;
using System;

namespace Flex
{	
	[Serializable]
	public class GameEventReference : FlexReference<UnityEngine.Object, GameEvent > {
		
		//public FlexFloatReference()
		//{ }

		//public FlexFloatReference(float	 value)
		//{
		//	UseConstant = true;
		//	ConstantValue = value;
		//}
	}
}
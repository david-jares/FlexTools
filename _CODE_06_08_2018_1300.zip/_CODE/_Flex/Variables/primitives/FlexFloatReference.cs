﻿using UnityEngine;
using UnityEngine.Events;
using Sirenix.Serialization;
using Sirenix.OdinInspector;
using System;

namespace Flex
{	
	[Serializable]
	public class FlexFloatReference : FlexReference<float, FlexFloatVariable > {
		
		//public FlexFloatReference()
		//{ }

		//public FlexFloatReference(float	 value)
		//{
		//	UseConstant = true;
		//	ConstantValue = value;
		//}
	}
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Flex;
using Sirenix.Serialization;
using Sirenix.OdinInspector;
namespace Flex
{
    [CreateAssetMenu(menuName = "Variables/FlexVariable/GameEvents/GameEvent_Object", order = 0)]
    public class GameEvent : FlexVariable<UnityEngine.Object> {

        
    }
}

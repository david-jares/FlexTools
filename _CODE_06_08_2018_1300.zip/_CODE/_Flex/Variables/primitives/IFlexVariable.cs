﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Flex{
	public interface IFlexVariable<T>  {
	
		T Value{get;set;}
	
	}
}
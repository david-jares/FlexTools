﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Flex;
using Sirenix.OdinInspector;
public class FlexTESTERRaiser : MonoBehaviour {

	public GameEventReference someGameEvent1;

	private void Update() {
	}
	[Button(ButtonSizes.Large)]
	public void doRaise(){
			someGameEvent1.Variable.Raise(this);
	}


}


using UnityEngine;
using UnityEngine.Events;
using Flex;
using Sirenix.Serialization;
using Sirenix.OdinInspector;
[CreateAssetMenu(menuName = "Variables/FlexVariable/Float", order = 0)]
public class FlexFloatVariable : FlexVariable<float> {
    
	protected override void OnEnable() {
		// Debug.Log(this.Value.ToString()) ;
        base.OnEnable();
	}
}

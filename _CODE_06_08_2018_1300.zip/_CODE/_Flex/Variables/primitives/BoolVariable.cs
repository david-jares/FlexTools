using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.Serialization;
using Flex;
[CreateAssetMenu(menuName = "Variables/FlexVariable/Bool", order = 0)]
public class BoolVariable : FlexVariable<bool>{
    
}

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Flex;
using Sirenix.Serialization;
using Sirenix.OdinInspector;
using System.Linq;
using System.Reflection;
namespace Flex
{   
    

    public class FlexVariable: SerializedScriptableObject
    {
        //private Object value;
        //public Object Value {
        //    get {  Debug.Log("Getting FlexVarBase : " + this.name); return value; }
        //    set {this.value = value ; } }

        // Wie w�re es mit "virtual Object getValue(); / setValue(Object o); ?? - was ist mit primitive types ?

        public readonly static HashSet<FlexVariable> allFlexVariableInstances = new HashSet<FlexVariable>();
        public HashSet<Object> allConnectedFlexRefsHolders = new HashSet<Object>();

        protected virtual void OnEnable()  { allFlexVariableInstances.Add   (this); 
        
        }
        protected virtual void OnDisable() { allFlexVariableInstances.Remove(this); }
        [Button(ButtonSizes.Medium)]
        public void printAllFlexVars()
        {
            Debug.Log("FlexVar List Length : " + allFlexVariableInstances.Count);
            foreach (var instance in allFlexVariableInstances)
            {
                Debug.Log("Name : " + instance.name + "   Type : " + instance.GetType());
            }
        }

        
    }


    public class FlexVariable<T>  : FlexVariable, IGameEvent //where T : Object //: GameEvent
    {

#if UNITY_EDITOR
        [Multiline]
        public string DeveloperDescription = "";
#endif


        [ShowInInspector, SerializeField] // Serializing the backing field is goofd enough for us, no need of serializing the propertx
        [OnValueChanged("OnInspectorChangedValueUpdateProperty")]
        private T value ;
        public  T Value
        {
            get
            {
                return value;
            }
            set
            {
                this.value = value;
                Raise(null);
                Debug.Log("Inside Property - SET");
            }
        }
        public void setValue<X>(X newValue, Object theCaller)where X : T{
            //this can be used for tracking and passing the Caller further ( use for Vizualisation of Vars)
            this.value = newValue;
            Raise(theCaller);
        }
        protected void OnInspectorChangedValueUpdateProperty() { // Workaround for calling set-method when changing the value in the inspector
            Debug.Log("Test protected Update on Inspector Change");
            Value = value;
        }


        // GAMEEVENT-PART
        public  readonly static List<FlexVariable<T>>  allSpecificInstances     = new List<FlexVariable<T>> ();
        protected override void OnEnable () {
          allSpecificInstances.Add   (this);
          allRegisteredEventListenerObjects = new List<Object>();
          base.OnEnable(); }
		protected override void OnDisable() { allSpecificInstances.Remove(this);  base.OnEnable(); }


        // for Standard Listeners that were setup in code
        public delegate void EventRaisedAction(Object theRaiser);
        public event        EventRaisedAction OnEventRaised ;
        
        public  List<UnityEngine.Object> allRegisteredEventListenerObjects = new List<UnityEngine.Object>();

        [Button("Raise the Event", ButtonSizes.Medium)]
        virtual public void Raise()   {Raise(null);  } // if not null , then invoke
        virtual public void Raise(Object theRaiser){OnEventRaised?.Invoke(theRaiser);}
        public void RegisterListener  (EventRaisedAction  eventRaisedCallback, Object listener) {OnEventRaised += eventRaisedCallback; allRegisteredEventListenerObjects.Add(listener);}
        public void UnRegisterListener(EventRaisedAction  eventRaisedCallback,Object listener) { OnEventRaised -= eventRaisedCallback;    allRegisteredEventListenerObjects.Remove (listener); }
        public void RegisterListener  (IGameEventListener listener)            { OnEventRaised += listener.OnEventRaised; allRegisteredEventListenerObjects.Add    ((UnityEngine.Object) listener);                  allRegisteredEventListenerObjects = allRegisteredEventListenerObjects.OrderBy(t => t.name).ToList<UnityEngine.Object>(); }
        public void UnregisterListener(IGameEventListener listener)            { OnEventRaised -= listener.OnEventRaised; allRegisteredEventListenerObjects.Remove ((UnityEngine.Object) listener); }


        //Debugging...

        [Button(ButtonSizes.Medium)]
        public void printMyInstances()
        {
            Debug.Log("Instance List Length : " + allSpecificInstances.Count);
            foreach (var instance in allSpecificInstances)
            {
                Debug.Log("Name : " + instance.name + "   Type : " + instance.GetType());

            }
        }
        [Button(ButtonSizes.Medium)]
        public void printAllEventListeners()
        {   
            if(OnEventRaised == null) { Debug.Log("Event is Null "); return; }
            Debug.Log("Event Listener-Array Length : " + OnEventRaised.GetInvocationList().Length );
            Debug.Log("Event Listener-Array Length : " + allRegisteredEventListenerObjects.Count );

            int x = 0;
            foreach(UnityEngine.Object o in allRegisteredEventListenerObjects) { Debug.Log(x++ + "  " + o.name);}
            //foreach (EventRaisedAction callback in OnEventRaised.GetInvocationList())
            //{
            //    Debug.Log(x++ + " Target Object : "     + callback.Target);
            //    Debug.Log(x + " Target ObjectName : " + (callback.Target as UnityEngine.Object).name);
            //}
        }
    }
}
 